import Navbar from "./navbar/Navbar";
import MainContainer from "./maincontainer/MainContainer";

function Dex() {
  return (
    <div>
      <Navbar />
      <MainContainer />
    </div>
  );
}

export default Dex;
